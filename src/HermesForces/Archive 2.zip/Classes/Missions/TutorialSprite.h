#ifndef TUTORIAL_TUT
#define TUTORIAL_TUT

class TutorialSprite
{
	

};

#endif // !TUTORIAL_TUT
