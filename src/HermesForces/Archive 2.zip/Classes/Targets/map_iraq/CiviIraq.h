//#ifndef __CIVI_IRAQ_H__
//#define __CIVI_IRAQ_H__
//
//#include "../IUnit.h"
//
//class CiviIraq : public IUnit
//{
//public:
//	CiviIraq(int type, int idTag, cocos2d::Point p);
//	int die();
//};
//
//#endif